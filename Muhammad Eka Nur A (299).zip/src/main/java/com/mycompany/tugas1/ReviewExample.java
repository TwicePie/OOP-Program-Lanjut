/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugas1;

/**
 *
 * @author EKA
 */
public class ReviewExample {
    public static void main(String[] args) {
        System.out.println(add(5,3)); //mengganti angka "a" dan "b" yang diinginkan 
    }
    
    public static int add(int a, int b){
        return a + b; //tempat proses penjumlahan angka "a" dengan "b"
    }
}
